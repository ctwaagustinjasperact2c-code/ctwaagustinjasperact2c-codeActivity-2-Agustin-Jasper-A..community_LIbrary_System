BOOKNEST - COMMUNITY LIBRARY MANAGEMENT SYSTEM
================================================

This is an original PHP + MySQL project for:
Activity #1: Sign In and Register pages.
Activity #2: Access Control, User Management, and CRUD operations.

REQUIREMENTS
- XAMPP (Apache + MySQL)
- PHP 8.0+ recommended
- MySQL / MariaDB

INSTALLATION
1. Extract the Community_Library_System folder into C:\xampp\htdocs\
2. Open XAMPP Control Panel and start Apache and MySQL.
3. Open http://localhost/phpmyadmin
4. Click Import and select database.sql from this project.
5. Open http://localhost/Community_Library_System/

DEFAULT ADMIN ACCOUNT
Email: admin@library.test
Password: LibraryAdmin123!

Sign in with the admin account and change its password by going to Members,
editing the administrator account, and entering a new password.

MEMBER ACCOUNT
Use the Register page to create a member account. Public registration always
creates a Member role. Only administrators can create or promote admin users.

FEATURES
- Secure password hashing using password_hash/password_verify
- Prepared PDO statements
- Session-based authentication and role checks
- CSRF token validation on forms
- Admin: create/read/update/delete books
- Admin: create/read/update/delete user accounts
- Admin: approve/reject borrowing requests and mark books returned
- Member: browse the catalog, request books, and view request history
- Book copy counts update when requests are approved and returned

DATABASE CONFIGURATION
Default XAMPP credentials are configured in config.php (user root, blank password).
If your MySQL credentials are different, edit config.php.

IMPORTANT
- Keep config.php and database credentials private when publishing publicly.
- Change the demo administrator password before real use.
- This is a classroom/demo project, not a production-ready library platform.
