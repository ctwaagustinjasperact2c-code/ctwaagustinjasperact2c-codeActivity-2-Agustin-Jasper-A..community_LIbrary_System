<?php
// Update these values if your local MySQL settings are different.
$host = 'localhost';
$db   = 'community_library';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false];
try { $pdo = new PDO($dsn, $user, $pass, $options); }
catch (PDOException $e) { exit('Database connection failed. Check config.php and import database.sql.'); }
if (session_status() === PHP_SESSION_NONE) { session_start(); }
