CREATE DATABASE IF NOT EXISTS community_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE community_library;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','member') NOT NULL DEFAULT 'member',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  author VARCHAR(140) NOT NULL,
  category VARCHAR(80) NOT NULL,
  isbn VARCHAR(40) DEFAULT NULL,
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS borrow_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('pending','approved','returned','rejected') NOT NULL DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Demo admin account. Change this password after your first login.
-- Email: admin@library.test | Password: LibraryAdmin123!
INSERT INTO users (full_name,email,password,role)
SELECT 'Library Administrator','admin@library.test','$2y$12$xcu.at8H4vQCYtFKb.6ZveXg4Jh/.FOrKxNDHK31ViUPW9K56d1tK','admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@library.test');

INSERT INTO books (title,author,category,isbn,total_copies,available_copies)
SELECT 'The Little Prince','Antoine de Saint-Exupéry','Fiction','9780156012195',4,4
WHERE NOT EXISTS (SELECT 1 FROM books WHERE title='The Little Prince' AND author='Antoine de Saint-Exupéry');
INSERT INTO books (title,author,category,isbn,total_copies,available_copies)
SELECT 'Atomic Habits','James Clear','Self-help','9780735211292',3,3
WHERE NOT EXISTS (SELECT 1 FROM books WHERE title='Atomic Habits' AND author='James Clear');
INSERT INTO books (title,author,category,isbn,total_copies,available_copies)
SELECT 'A Brief History of Time','Stephen Hawking','Science','9780553380163',2,2
WHERE NOT EXISTS (SELECT 1 FROM books WHERE title='A Brief History of Time' AND author='Stephen Hawking');
