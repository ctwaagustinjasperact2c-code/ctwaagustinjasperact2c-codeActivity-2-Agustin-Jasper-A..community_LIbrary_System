<?php
require_once 'includes/functions.php';
if(logged_in()){header('Location: dashboard.php');exit;}
$pageTitle='Welcome';require 'includes/header.php';
?>
<section class="hero"><div><div class="eyebrow">A place for curious minds</div><h1>Every book opens a new world.</h1><p>Discover stories, learn something new, and borrow your next favorite book from your neighborhood library.</p><a class="button light" href="register.php">Become a member →</a></div><div class="hero-art">📚</div></section>
<div class="section-head"><div><div class="eyebrow" style="color:#176b55">WELCOME TO BOOKNEST</div><h2>A little more knowledge, every day.</h2></div></div>
<div class="grid"><article class="card"><div class="book-cover">📖</div><h3>Explore the shelves</h3><p class="muted">Browse books across fiction, science, history, and more.</p></article><article class="card"><div class="book-cover">🤝</div><h3>Join the community</h3><p class="muted">Create a free member account and keep track of your requests.</p></article><article class="card"><div class="book-cover">🌱</div><h3>Keep on learning</h3><p class="muted">Find your next read and grow one page at a time.</p></article></div>
<?php require 'includes/footer.php'; ?>
