<?php
require_once 'includes/functions.php';
if(logged_in()){header('Location: dashboard.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$name=trim($_POST['full_name']??'');$email=strtolower(trim($_POST['email']??''));$password=$_POST['password']??'';$confirm=$_POST['confirm_password']??'';
 if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<8){$error='Enter your name, a valid email, and a password with at least 8 characters.';}
 elseif($password!==$confirm){$error='The passwords do not match.';}
 else{try{$stmt=$pdo->prepare('INSERT INTO users(full_name,email,password,role) VALUES(?,?,?,?)');$stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),'member']);flash('Your member account has been created. Please sign in.');header('Location: login.php');exit;}catch(PDOException $ex){$error=$ex->getCode()==='23000'?'That email address is already registered.':'Registration could not be completed.';}}
}
$pageTitle='Create account';require 'includes/header.php';?>
<div class="auth-wrap"><section class="auth-card"><div class="eyebrow" style="color:#176b55">JOIN BOOKNEST</div><h1>Create your account</h1><p class="muted">Become a member of your community library.</p><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="field"><label>Full name</label><input name="full_name" required maxlength="120" value="<?=e($_POST['full_name']??'')?>"></div><div class="field"><label>Email address</label><input type="email" name="email" required value="<?=e($_POST['email']??'')?>"></div><div class="field"><label>Password</label><input type="password" name="password" minlength="8" required></div><div class="field"><label>Confirm password</label><input type="password" name="confirm_password" minlength="8" required></div><button class="button full">Create member account</button></form><p class="muted" style="text-align:center;margin-bottom:0">Already a member? <a href="login.php">Sign in</a></p></section></div>
<?php require 'includes/footer.php';?>
